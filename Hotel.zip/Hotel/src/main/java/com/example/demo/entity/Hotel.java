package com.example.demo.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "HOTEL")
public class Hotel {
		
		@Id
		private String hotelId;
		private String customerId;
		private String hotelName;
		private String city;
		private Integer noOfRoomsAvail;
		
		public Hotel() {}

		public Hotel(String hotelId, String customerId, String hotelName, String city, Integer noOfRoomsAvail) {
			super();
			this.hotelId = hotelId;
			this.customerId = customerId;
			this.hotelName = hotelName;
			this.city = city;
			this.noOfRoomsAvail = noOfRoomsAvail;
		}

		public String getHotelId() {
			return hotelId;
		}

		public void setHotelId(String hotelId) {
			this.hotelId = hotelId;
		}

		public String getCustomerId() {
			return customerId;
		}

		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}

		public String getHotelName() {
			return hotelName;
		}

		public void setHotelName(String hotelName) {
			this.hotelName = hotelName;
		}

		public String getCity() {
			return city;
		}

		public void setCity(String city) {
			this.city = city;
		}

		public Integer getNoOfRoomsAvail() {
			return noOfRoomsAvail;
		}

		public void setNoOfRoomsAvail(Integer noOfRoomsAvail) {
			this.noOfRoomsAvail = noOfRoomsAvail;
		}

		@Override
		public String toString() {
			return "Hotel [hotelId=" + hotelId + ", customerId=" + customerId + ", hotelName=" + hotelName + ", city="
					+ city + ", noOfRoomsAvail=" + noOfRoomsAvail + "]";
		}
		
		
}
